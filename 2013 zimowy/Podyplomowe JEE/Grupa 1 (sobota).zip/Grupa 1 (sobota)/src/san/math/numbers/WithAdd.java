package san.math.numbers;

public interface WithAdd {

  Num add(Complex other);
  
  Num add(Real other);
  
  Num add(Int other);
  
}
