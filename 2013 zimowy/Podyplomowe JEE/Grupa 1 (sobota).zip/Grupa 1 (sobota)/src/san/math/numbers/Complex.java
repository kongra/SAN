package san.math.numbers;

public abstract class Complex extends Num {
  
  public abstract Num re();
  
  public abstract Num im();

  @Override
  public Num add(Complex other) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Num add(Real other) {
    // TODO Auto-generated method stub
    return null;
  }

  @Override
  public Num add(Int other) {
    // TODO Auto-generated method stub
    return null;
  }

}
