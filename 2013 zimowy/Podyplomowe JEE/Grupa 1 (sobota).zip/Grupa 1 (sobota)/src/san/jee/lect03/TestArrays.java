package san.jee.lect03;

public class TestArrays {

  public static void main(String[] args) {
//    int[] tab = {1, 2, 3};
//    double[] tab1 = tab;
//    
//    tab1[0] = 3.14;
    
    String[] tab = {"xyz", "abc"};
    Object[] arr = tab;
    arr[0] = 1;
    
  }

}
