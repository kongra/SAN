package san.coll.fn;

public interface Unary<R, S> {

  R call(S param);
  
}
