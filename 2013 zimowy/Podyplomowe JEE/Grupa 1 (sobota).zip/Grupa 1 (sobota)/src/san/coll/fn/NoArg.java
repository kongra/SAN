package san.coll.fn;

public interface NoArg<T> {

  T call();
  
}
