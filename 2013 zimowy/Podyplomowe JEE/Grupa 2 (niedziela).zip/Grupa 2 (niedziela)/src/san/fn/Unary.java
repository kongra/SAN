package san.fn;

public interface Unary {

  Object call(Object arg);
  
}
