package san.fn;

public interface Nullary {

  Object call();
  
}
