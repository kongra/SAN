package san.fn;

public interface UnaryBody {

  void run(Object element);
  
}
