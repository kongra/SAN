package san.fn;

public interface Varar {

  Object call(Object... args);
  
}
