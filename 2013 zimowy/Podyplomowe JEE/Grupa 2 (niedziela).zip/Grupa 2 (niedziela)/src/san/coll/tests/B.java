package san.coll.tests;

public class B extends A {

}
