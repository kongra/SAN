package san.coll.tests;

public class A {

  public A() {
    ;
  }
  
}
