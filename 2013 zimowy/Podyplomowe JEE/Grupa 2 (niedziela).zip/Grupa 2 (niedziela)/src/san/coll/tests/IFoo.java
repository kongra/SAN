package san.coll.tests;

public interface IFoo {

  void foo();
  
}
