#!/bin/sh
mvn versions:display-dependency-updates
