#!/bin/sh
mvn clean test -Dtest=!edu.san.test.jmh.JmhRunnerTest
